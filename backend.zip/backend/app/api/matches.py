from fastapi import APIRouter
from app.models.schemas import Item

router = APIRouter()

@router.get("/search")
async def find_gear(query: str, school: str):
    # This would call match_engine.py to query Elasticsearch 
    # For now, returning mock data for your demo
    return [
        {"id": "1", "name": f"{query} - Pro", "grade": "Grade A", "school": school},
        {"id": "2", "name": f"{query} - Standard", "grade": "Grade B", "school": school}
    ]